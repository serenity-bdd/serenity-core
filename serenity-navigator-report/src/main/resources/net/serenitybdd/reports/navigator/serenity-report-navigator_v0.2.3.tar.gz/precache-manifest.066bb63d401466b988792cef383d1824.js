self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "08ab01aee69c16fd5db124f938591434",
    "url": "./index.html"
  },
  {
    "revision": "f23cb4a619831c407fd8",
    "url": "./static/css/main.5ab818d3.chunk.css"
  },
  {
    "revision": "1d2bed8cf5ac0eb1471b",
    "url": "./static/js/2.40b584c6.chunk.js"
  },
  {
    "revision": "f1228651ed12f837338c31fb55903ecf",
    "url": "./static/js/2.40b584c6.chunk.js.LICENSE.txt"
  },
  {
    "revision": "f23cb4a619831c407fd8",
    "url": "./static/js/main.c84ab275.chunk.js"
  },
  {
    "revision": "14224328b3d1963ed1ef",
    "url": "./static/js/runtime-main.7b065930.js"
  },
  {
    "revision": "24c0f792cd867deb8b31243b583897d4",
    "url": "./static/media/noun_Expand proportionally_1691340.24c0f792.svg"
  },
  {
    "revision": "ce37432ae186137a126c145f7f25c04c",
    "url": "./static/media/noun_Split Vertical_2439343.ce37432a.svg"
  },
  {
    "revision": "7fd66482d6c8e3bb43a3631eb2d100b3",
    "url": "./static/media/noun_collapse vertical_2439339.7fd66482.svg"
  }
]);